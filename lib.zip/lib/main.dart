import 'package:flutter/material.dart';
import 'package:flutter_pdf_gen/app.dart';

void main() {
  runApp(const App());
}
